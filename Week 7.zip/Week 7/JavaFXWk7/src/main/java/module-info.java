module coit11134.javafxwk7 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens coit11134.javafxwk7 to javafx.fxml;
    exports coit11134.javafxwk7;
}
